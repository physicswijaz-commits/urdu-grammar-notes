/* ==========================================================================
   اردو دوم سال — Header + bottom tab-bar auto-hide on scroll
   While reading (scrolling down), the sticky header and fixed tab-bar both
   slide out of view to give the page more room. Scrolling up, or reaching
   the top/bottom of the page, brings them back immediately.
   ========================================================================== */
(function () {
  const header = document.querySelector('header');
  const tabBar = document.querySelector('.tab-bar');
  if (!header && !tabBar) return;

  let lastY = window.scrollY;
  let ticking = false;

  function onScroll() {
    const y = window.scrollY;
    const goingDown = y > lastY;
    const pastThreshold = y > 80;
    const nearBottom = window.innerHeight + y >= document.documentElement.scrollHeight - 40;
    const shouldHide = goingDown && pastThreshold && !nearBottom;

    if (tabBar) tabBar.classList.toggle('nav-hidden', shouldHide);
    if (header) {
      header.classList.toggle('nav-hidden', shouldHide);
      header.classList.toggle('elevated', y > 4);
    }

    lastY = y;
    ticking = false;
  }

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(onScroll);
      ticking = true;
    }
  }, { passive: true });
})();
