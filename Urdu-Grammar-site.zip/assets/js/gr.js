/* English Grammar — features. Runs fully in the browser; saved data stays in localStorage (namespaced "gr:"). */
(function () {
  'use strict';
  var CFG = window.GR_CFG || {}, D = window.GR_DATA || { topics: [] }, T = D.topics;
  var PAGE = location.pathname.split('/').pop() || 'index.html';
  var BACKUP_KEYS = ['readPages', 'lessonProgress', 'visitDates', 'fontScale', 'theme', 'focusMode', 'examDate', 'grammarQuiz', 'quizProgress', 'annSeen'];
  function get(k, f) { try { var v = localStorage.getItem(k); return v === null ? f : JSON.parse(v); } catch (e) { return f; } }
  function put(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function icons() { if (window.lucide) try { lucide.createIcons(); } catch (e) {} }
  function el(h) { var d = document.createElement('div'); d.innerHTML = h.trim(); return d.firstChild; }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(s, r) { return (r || document).querySelector(s); }
  function toast(m) {
    document.querySelectorAll('.x-toast').forEach(function (t) { t.remove(); });
    var t = el('<div class="x-toast" role="status">' + esc(m) + '</div>'); document.body.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 300); }, 2400);
  }
  function shareUrl() { return CFG.url || (location.origin + location.pathname.replace(/[^/]*$/, '')); }
  function copy(t) {
    function ok() { toast('لنک کاپی ہو گیا'); }
    function fb() { var i = document.createElement('textarea'); i.value = t; document.body.appendChild(i); i.select(); try { document.execCommand('copy'); ok(); } catch (e) {} i.remove(); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, fb); else fb();
  }
  function doShare() {
    var url = shareUrl(), msg = 'اردو قواعد (دوم سال): نوٹس، MCQ ٹیسٹ اور مختصر سوالات۔ ';
    if (navigator.share) navigator.share({ title: 'اردو قواعد', text: msg, url: url }).catch(function () {}); else copy(url);
  }
  /* ---- quiz results: grammarQuiz = { "grammar-1.html": { "1": chosenIndex, ..., "_t": total } } ---- */
  function result(t) {
    var st = (get('grammarQuiz', {}) || {})[t.file] || {}, done = 0, ok = 0;
    Object.keys(t.answers).forEach(function (q) { if (typeof st[q] === 'number') { done++; if (st[q] === t.answers[q]) ok++; } });
    return { done: done, ok: ok, total: Object.keys(t.answers).length };
  }
  function readSet() { var r = get('readPages', []); return Array.isArray(r) ? r : []; }

  /* ---------- update notice ---------- */
  if ('serviceWorker' in navigator) {
    var had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!had || $('.x-update')) return;
      var b = el('<div class="x-update" role="status"><span>نیا ورژن آ گیا ہے</span><button type="button">ابھی تازہ کریں</button></div>');
      b.querySelector('button').onclick = function () { location.reload(); }; document.body.appendChild(b);
    });
  }
  /* ---------- announcement banner (announcement.json: {"id":"..","text":".."}) ---------- */
  function announce() {
    if (!window.fetch || location.protocol === 'file:') return;
    fetch('announcement.json', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (a) {
      if (!a || !a.text || !a.id || get('annSeen', '') === a.id) return;
      var host = $('main'); if (!host) return;
      var b = el('<div class="gr-ann" role="status"><i data-lucide="megaphone"></i><span></span><button type="button" aria-label="بند کریں">×</button></div>');
      b.querySelector('span').textContent = a.text;
      b.querySelector('button').onclick = function () { put('annSeen', a.id); b.remove(); };
      host.insertBefore(b, host.firstChild); icons();
    }).catch(function () {});
  }
  /* ---------- install ---------- */
  var deferred = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; var b = $('#t-install'); if (b) b.hidden = false; });
  function installCard() {
    var standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone;
    if (standalone) return null;
    var c = el('<div class="gr-install"><div><b>ایپ انسٹال کریں</b><span id="ic-hint">ہوم اسکرین سے کھولیں، انٹرنیٹ کے بغیر بھی۔</span></div><button type="button" id="ic-btn">انسٹال</button></div>');
    var btn = c.querySelector('#ic-btn'), hint = c.querySelector('#ic-hint');
    btn.onclick = function () {
      if (deferred) { deferred.prompt(); deferred.userChoice.finally(function () { deferred = null; }); }
      else { hint.textContent = 'Chrome کے مینو (⋮) سے «Add to Home screen» منتخب کریں (آئی فون میں: شیئر، پھر «Add to Home Screen»)۔'; btn.hidden = true; }
    };
    window.addEventListener('appinstalled', function () { c.remove(); });
    return c;
  }
  /* ---------- exam date ---------- */
  function examCard(visible) {
    var c = el('<div class="x-card ' + (visible ? 'gr-exam' : 'x-exam') + '"><span class="x-ic"><i data-lucide="calendar-days"></i></span><div class="x-tx"><b>امتحان کی تاریخ</b><small></small></div><label class="x-date"><input type="date" aria-label="امتحان کی تاریخ"></label></div>');
    var i = c.querySelector('input'), sm = c.querySelector('small'); i.value = get('examDate', '');
    function paint() {
      var v = i.value; if (!v) { sm.textContent = 'تاریخ چنیں تو باقی دن یہاں دکھیں گے'; return; }
      var p = v.split('-'), n = new Date(), d = Math.round((Date.UTC(+p[0], +p[1] - 1, +p[2]) - Date.UTC(n.getFullYear(), n.getMonth(), n.getDate())) / 864e5);
      sm.textContent = d > 0 ? 'امتحان میں ' + d + ' دن باقی ہیں' : d === 0 ? 'امتحان آج ہے — اللہ کامیاب کرے!' : 'تاریخ گزر چکی، نئی تاریخ چنیں';
    }
    i.addEventListener('change', function () { if (i.value) put('examDate', i.value); else localStorage.removeItem('examDate'); paint(); toast('تاریخ محفوظ ہو گئی'); });
    paint(); return c;
  }
  /* ---------- home ---------- */
  function initHome() {
    var main = $('main'), hero = $('.hero'); if (!main || !hero) return;
    var ic = installCard(); if (ic) hero.insertAdjacentElement('afterend', ic);
    var q = $('.ios-quick-list'); if (!q) return;
    var wrap = el('<div class="x-home"></div>'); wrap.appendChild(examCard(false));
    /* topics to revisit: tests finished below 60 percent, then tests not started */
    var weak = [], fresh = [];
    T.forEach(function (t) { if (!t.mcq) return; var r = result(t); if (r.done && r.total && r.ok / r.total < 0.6 && r.done === r.total) weak.push([t, r]); else if (!r.done) fresh.push(t); });
    var rows = '';
    weak.slice(0, 3).forEach(function (w) { rows += '<a class="x-row" href="' + w[0].file + '#mashq"><i data-lucide="rotate-ccw"></i><span><b>' + esc(w[0].title) + '</b><small>نتیجہ ' + w[1].ok + '/' + w[1].total + ' — ٹیسٹ دوبارہ دیں</small></span><i data-lucide="chevron-left"></i></a>'; });
    if (!rows) fresh.slice(0, 3).forEach(function (t) { rows += '<a class="x-row" href="' + t.file + '#mashq"><i data-lucide="pencil-line"></i><span><b>' + esc(t.title) + '</b><small>' + t.mcq + ' MCQ باقی ہیں</small></span><i data-lucide="chevron-left"></i></a>'; });
    if (rows) wrap.appendChild(el('<div class="x-card x-today"><h3><i data-lucide="target"></i> ' + (weak.length ? 'دوبارہ کوشش کریں' : 'اگلا ٹیسٹ') + '</h3>' + rows + '</div>'));
    q.parentNode.insertBefore(wrap, q); icons();
  }
  /* ---------- lesson ---------- */
  function initLesson() {
    var idx = -1; T.forEach(function (t, i) { if (t.file === PAGE) idx = i; }); if (idx < 0) return;
    var main = $('main'), head = $('.chapter-header');
    var words = (main.innerText || '').split(/\s+/).length, mins = Math.max(1, Math.round(words / 160));
    var t = T[idx];
    var tools = el('<div class="x-lesson-tools"><span class="x-chip"><i data-lucide="clock"></i>پڑھنے کا وقت: تقریباً ' + mins + ' منٹ</span>' +
      (document.getElementById('mcq') ? '<button type="button" class="x-chip" id="g-prac"><i data-lucide="pencil-line"></i>مشق</button>' : '') +
      '<button type="button" class="x-chip" id="g-share"><i data-lucide="share-2"></i>شیئر</button>' +
      '<a class="x-chip" id="g-report" target="_blank" rel="noopener"><i data-lucide="flag"></i>غلطی بتائیں</a></div>');
    if (head) head.parentNode.insertBefore(tools, head.nextSibling);
    var gp = $('#g-prac'); if (gp) gp.onclick = function () { var d = document.querySelector('.lesson-dock [data-pane="mashq"]'); if (d) d.click(); else { var m = document.getElementById('mcq'); if (m) m.scrollIntoView(); } };
    $('#g-share').onclick = function () { var u = shareUrl() + t.file; if (navigator.share) navigator.share({ title: t.title, url: u }).catch(function () {}); else copy(u); };
    $('#g-report').href = 'https://wa.me/' + (CFG.wa || '') + '?text=' + encodeURIComponent('غلطی کی اطلاع — اردو قواعد: ' + t.title);
    var L = T.filter(function (x) { return x.kind === t.kind; }), li = L.indexOf(t), prev = L[li - 1], next = L[li + 1];
    var nav = el('<nav class="gr-pn" aria-label="موضوعات">' + (prev ? '<a href="' + prev.file + '"><i data-lucide="arrow-right"></i><span><small>پچھلا</small>' + esc(prev.title) + '</span></a>' : '<span></span>') +
      (next ? '<a href="' + next.file + '" class="next"><span><small>اگلا</small>' + esc(next.title) + '</span><i data-lucide="arrow-left"></i></a>' : '<a href="index.html" class="next"><span><small>مکمل</small>فہرست پر واپس</span><i data-lucide="home"></i></a>') + '</nav>');
    main.appendChild(nav);
    icons();
  }
  /* ---------- progress ---------- */
  function initProgress() {
    var host = $('#gr-progress'), read = readSet(), done = 0, tot = 0, ok = 0, answered = 0;
    var rows = T.map(function (t) {
      var r = result(t); if (t.kind !== 'test') { tot += r.total; answered += r.done; ok += r.ok; } var pct = r.total ? Math.round(r.ok * 100 / r.total) : 0; var isRead = read.indexOf(t.file) > -1;
      var cls = !t.mcq ? (isRead ? 'good' : 'none') : !r.done ? 'none' : r.done < r.total ? 'part' : pct >= 60 ? 'good' : 'weak';
      var state = !t.mcq ? (isRead ? 'مطالعہ مکمل' : 'شروع نہیں') : !r.done ? 'شروع نہیں' : r.done < r.total ? r.done + '/' + r.total + ' جواب دیے' : r.ok + '/' + r.total + ' درست (' + pct + '%)';
      return '<a class="gr-prow ' + cls + '" href="' + t.file + (t.mcq ? '#mashq' : '') + '"><span class="n">' + (t.tag || ((t.n < 10 ? '0' : '') + t.n)) + '</span><span class="tx"><b>' + esc(t.title) + '</b><small>' + (t.mcq && read.indexOf(t.file) > -1 ? 'مطالعہ مکمل · ' : '') + state + '</small></span><span class="bar"><i style="width:' + (r.total ? Math.round(r.done * 100 / r.total) : 0) + '%"></i></span></a>';
    }).join('');
    var nRead = T.filter(function (t) { return read.indexOf(t.file) > -1; }).length;
    host.innerHTML = '<div class="gr-stats"><div class="gr-stat"><i data-lucide="check-check"></i><b>' + nRead + '/' + T.length + '</b><span>مطالعہ مکمل</span></div>' +
      '<div class="gr-stat"><i data-lucide="pencil-line"></i><b>' + answered + '/' + tot + '</b><span>MCQ حل کیے</span></div>' +
      '<div class="gr-stat"><i data-lucide="target"></i><b>' + (answered ? Math.round(ok * 100 / answered) + '%' : '—') + '</b><span>درستی</span></div></div>' +
      '<div class="gr-plist">' + rows + '</div>';
    icons();
  }
  /* ---------- more ---------- */
  function backup() {
    var out = { app: 'urdu-grammar', saved: new Date().toISOString(), data: {} };
    BACKUP_KEYS.forEach(function (k) { var v = localStorage.getItem(k); if (v !== null) out.data[k] = v; });
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(out)], { type: 'application/json' }));
    a.download = 'urdu-grammar-backup.json'; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast('بیک اپ محفوظ ہو گیا');
  }
  function restore(f) {
    var r = new FileReader();
    r.onload = function () {
      try {
        var o = JSON.parse(r.result); if (!o || o.app !== 'urdu-grammar' || !o.data) throw 0;
        if (!confirm('موجودہ پیش رفت بیک اپ سے بدل جائے گی۔ جاری رکھیں؟')) return;
        Object.keys(o.data).forEach(function (k) { if (BACKUP_KEYS.indexOf(k) > -1) localStorage.setItem(k, o.data[k]); });
        toast('بحال ہو گیا'); setTimeout(function () { location.reload(); }, 800);
      } catch (e) { toast('یہ فائل درست بیک اپ نہیں ہے'); }
    };
    r.readAsText(f);
  }
  function offline() {
    var m = $('#gr-offline'); if (!m) return;
    if (!('serviceWorker' in navigator) || !window.caches) { m.textContent = 'یہ براؤزر آف لائن محفوظ کرنے کی سہولت نہیں دیتا۔'; return; }
    m.textContent = 'جانچ ہو رہی ہے…';
    navigator.serviceWorker.ready.then(function () { return caches.keys(); }).then(function (ks) {
      var k = ks.filter(function (n) { return n.indexOf('urgrammar-') === 0; })[0]; if (!k) throw 0;
      return caches.open(k).then(function (c) { return c.keys(); });
    }).then(function (r) { m.textContent = 'آف لائن تیار ہے — ' + r.length + ' فائلیں اس فون میں محفوظ ہیں۔'; }).catch(function () { m.textContent = 'ابھی تیار نہیں۔ انٹرنیٹ پر ایک بار صفحہ تازہ کر کے دوبارہ کوشش کریں۔'; });
  }
  function initMore() {
    $('#gr-exam').appendChild(examCard(true));
    $('#t-share').onclick = doShare; $('#t-backup').onclick = backup;
    $('#t-restore').onclick = function () { $('#t-file').click(); };
    $('#t-file').onchange = function (e) { if (e.target.files[0]) restore(e.target.files[0]); e.target.value = ''; };
    $('#t-offline').onclick = offline;
    $('#t-reset').onclick = function () {
      if (!confirm('مطالعہ کے نشان اور MCQ جوابات صاف کر دیں؟ (رکھنا ہو تو پہلے بیک اپ لے لیں۔)')) return;
      ['readPages', 'lessonProgress', 'grammarQuiz', 'quizProgress', 'visitDates', 'examDate'].forEach(function (k) { localStorage.removeItem(k); });
      toast('صاف ہو گیا'); setTimeout(function () { location.reload(); }, 700);
    };
    var ib = $('#t-install'); if (deferred) ib.hidden = false;
    ib.onclick = function () { if (deferred) { deferred.prompt(); deferred = null; ib.hidden = true; } };
    if (/iphone|ipad/i.test(navigator.userAgent) && !navigator.standalone) $('#gr-offline').textContent = 'آئی فون میں: Safari کے شیئر مینو سے «Add to Home Screen» منتخب کریں۔';
  }
  function initShare() {
    var url = shareUrl(), msg = 'اردو قواعد (دوم سال، KPK): نوٹس، MCQ ٹیسٹ اور مختصر سوالات۔ ';
    $('#s-wa').onclick = function () { window.open('https://wa.me/?text=' + encodeURIComponent(msg + url), '_blank', 'noopener'); };
    var sy = $('#s-sys'); if (!navigator.share) sy.hidden = true; else sy.onclick = doShare;
    $('#s-copy').onclick = function () { copy(url); };
    var img = $('#s-qr'); img.onerror = function () { img.closest('.gr-qr').hidden = true; };
  }
  document.addEventListener('DOMContentLoaded', function () {
    var f = { 'index.html': initHome, '': initHome, 'progress.html': initProgress, 'more.html': initMore, 'share.html': initShare }[PAGE];
    if (/^(grammar|insha)-\d+\.html$/.test(PAGE)) f = initLesson;
    try { if (f) f(); } catch (e) { if (window.console) console.error(e); }
    if (PAGE === 'index.html' || PAGE === '') announce();
    icons();
  });
})();
