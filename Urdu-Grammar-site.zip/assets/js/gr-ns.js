/* Keeps this site's saved data separate from the other notes sites (they share one web address). Load first. */
(function(){
if(window.__ugns) return; window.__grns=1;
var P='ug:', SP=Storage.prototype, g=SP.getItem, s=SP.setItem, r=SP.removeItem;
SP.getItem=function(x){ return this===localStorage?g.call(this,P+x):g.call(this,x); };
SP.setItem=function(x,v){ return this===localStorage?s.call(this,P+x,v):s.call(this,x,v); };
SP.removeItem=function(x){ return this===localStorage?r.call(this,P+x):r.call(this,x); };
})();
